"""Small compatibility adapter around the locked stock RSL-RL PPO."""
import copy
import torch
from tensordict import TensorDict
from rsl_rl.algorithms import PPO
from rsl_rl.runners import OnPolicyRunner
import rsl_rl.runners.on_policy_runner as runner_module


class FinalObservationPPO(PPO):
    """Bootstrap truncations from reset-before observations, then use stock PPO."""
    def process_env_step(self,obs,rewards,dones,extras):
        cleaned=dict(extras)
        timeout=cleaned.pop('time_outs',torch.zeros_like(dones,dtype=torch.bool)).bool()
        terminal=cleaned.get('terminated',torch.zeros_like(timeout)).bool()
        bootstrap=timeout & (~terminal)
        adjusted=rewards
        self.last_timeout_bonus=torch.zeros_like(rewards)
        if bool(bootstrap.any()):
            if 'final_observation' not in cleaned or 'final_observation_valid' not in cleaned:
                raise RuntimeError('time limit without a valid pre-reset final observation')
            if not cleaned['final_observation_valid'][bootstrap].all():
                raise RuntimeError('missing final observation for a truncated transition')
            final=TensorDict(cleaned['final_observation'],batch_size=[len(dones)]).to(self.device)
            with torch.no_grad():
                values=self.policy.evaluate(final).squeeze(-1)
            self.last_timeout_bonus=self.gamma*values*bootstrap.to(values.dtype)
            adjusted=rewards+self.last_timeout_bonus
        # Remove time_outs so upstream cannot add its old V(s_t) bootstrap.
        # Terminal transitions keep their unmodified rewards and done mask.
        super().process_env_step(obs,adjusted,dones,cleaned)


runner_module.FinalObservationPPO=FinalObservationPPO


class NativeRunner(OnPolicyRunner):
    def __init__(self,env,train_cfg,**kwargs):
        cfg=copy.deepcopy(train_cfg)
        cfg['algorithm']['class_name']='FinalObservationPPO'
        super().__init__(env,cfg,**kwargs)
