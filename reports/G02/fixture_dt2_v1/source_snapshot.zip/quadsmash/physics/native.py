"""Shared force, geometry and event accounting for native PhysX shuttle tasks.

This module never moves a ball or applies contact impulses. PhysX handles
collisions; contact flags require filtered engine forces, not proximity.
"""
from pathlib import Path
import json
import torch


def physics_contract():
    return json.loads((Path(__file__).resolve().parents[2] / "configs/shuttle_physics_v2.json").read_text())


def drag_force(velocity, mass, coefficient, wind):
    relative = velocity - torch.as_tensor(wind, device=velocity.device, dtype=velocity.dtype)
    return -mass * coefficient * relative.norm(dim=-1, keepdim=True) * relative


def quat_rotate(q, vector):
    xyz = q[..., 1:]
    t = 2 * torch.linalg.cross(xyz, vector, dim=-1)
    return vector + q[..., :1] * t + torch.linalg.cross(xyz, t, dim=-1)


def sphere_box_gap(ball_position, box_position, box_quaternion, half_extents, radius):
    inverse = torch.cat((box_quaternion[..., :1], -box_quaternion[..., 1:]), dim=-1)
    local = quat_rotate(inverse, ball_position - box_position)
    delta = local.abs() - torch.as_tensor(half_extents, device=local.device, dtype=local.dtype)
    return delta.clamp_min(0).norm(dim=-1) + delta.max(dim=-1).values.clamp_max(0) - radius


def segment_plane_crossing(previous, current, axis, coordinate, direction=1):
    """Interpolate a directed center crossing; returns mask, fraction, point."""
    a, b = previous[..., axis] - coordinate, current[..., axis] - coordinate
    mask = (a * direction < 0) & (b * direction >= 0)
    denominator = b - a
    fraction = torch.where(mask, -a / torch.where(denominator.abs() > 1e-12, denominator, torch.ones_like(b)), torch.zeros_like(b)).clamp(0, 1)
    point = previous + fraction[..., None] * (current - previous)
    return mask, fraction, point


class ContactEpisodes:
    """Count force-confirmed contacts, rearming after measured separation."""

    def __init__(self, count, device, threshold=0.001, separation=0.002):
        self.active = torch.zeros(count, dtype=torch.bool, device=device)
        self.count = torch.zeros(count, dtype=torch.long, device=device)
        self.clear_frames = torch.zeros(count, dtype=torch.long, device=device)
        self.threshold = threshold
        self.separation = separation

    def reset(self, ids):
        self.active[ids] = False
        self.count[ids] = 0
        self.clear_frames[ids] = 0

    def update(self, filtered_force, gap):
        touching = filtered_force.norm(dim=-1) > self.threshold
        separated = (~touching) & (gap > self.separation)
        self.clear_frames.copy_(torch.where(separated, self.clear_frames + 1, torch.zeros_like(self.clear_frames)))
        self.active &= self.clear_frames < 2
        new = touching & (~self.active)
        self.count += new.long()
        self.active |= touching
        return new, touching


def configure_ccd(stage, body_paths, collider_paths, material_path=None):
    """Set engine CCD and small contact offsets before starting simulation."""
    from pxr import PhysxSchema, UsdShade
    cfg = physics_contract()
    for path in body_paths:
        prim = stage.GetPrimAtPath(path)
        if not prim:
            raise ValueError(f"Missing collision body: {path}")
        api = PhysxSchema.PhysxRigidBodyAPI.Apply(prim)
        api.CreateEnableCCDAttr(cfg["sweep_ccd"])
        api.CreateEnableSpeculativeCCDAttr(cfg["speculative_ccd"])
    for path in collider_paths:
        prim = stage.GetPrimAtPath(path)
        if not prim:
            raise ValueError(f"Missing collider: {path}")
        api = PhysxSchema.PhysxCollisionAPI.Apply(prim)
        api.CreateContactOffsetAttr(cfg["contact_offset_m"])
        api.CreateRestOffsetAttr(cfg["rest_offset_m"])
        if material_path:
            UsdShade.MaterialBindingAPI.Apply(prim).Bind(
                UsdShade.Material(stage.GetPrimAtPath(material_path)),
                bindingStrength=UsdShade.Tokens.strongerThanDescendants, materialPurpose="physics")
