#!/usr/bin/env python3
"""Fast full-load dynamic reach curriculum before costly shuttle rollouts.

No ball or collision success is claimed. The near-net start is an explicit
optional curriculum, not the canonical G07 ground evaluation distribution.
"""
import argparse,json,signal,sys,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from isaaclab.app import AppLauncher
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--num-envs',type=int,default=128);p.add_argument('--generations',type=int,default=12);p.add_argument('--seed',type=int,default=714101);p.add_argument('--root-x',type=float,default=0.);AppLauncher.add_app_launcher_args(p);a=p.parse_args();app=AppLauncher(a).app
import torch
from isaaclab_rl.rsl_rl import RslRlVecEnvWrapper
from quadsmash.tasks.stand.jump_env import JumpEnv,JumpEnvCfg
from quadsmash.physics.native import quat_rotate

LOW=[.14,.06,.05,.15,-.70,-.40,-.40,-1.30,-.75,.1,-2.7,0.,.7,.7,-2.2,-1.,-.35,-.4,-.4,-.4,-.4]+[-.45]*6
HIGH=[.38,.30,.40,.65,-.15,1.2,1.2,-.837,.75,1.5,-1.2,.25,1.3,1.3,-1.4,1.,.35,.4,.4,.4,.4]+[.45]*6
INITIAL=[.2621,.1345,.35,.525,-.454,.365,.903,-.95,0.,-.108,-2.02,.124,1.02,1.05,-1.775,-.20,0.,0.,0.,0.,0.]+[0.]*6
stopping=False
def stop(*_):
 global stopping;stopping=True
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)

def main():
 a.output.mkdir(parents=True,exist_ok=True);cfg=JumpEnvCfg();cfg.scene.num_envs=a.num_envs;cfg.seed=a.seed;cfg.sim.device='cuda:0';cfg.robot.init_state.pos=(a.root_x,0.,.323);cfg.sim.dt=.002;cfg.decimation=5;cfg.sim.render_interval=5;cfg.episode_length_s=4.
 class ReachEnv(JumpEnv):
  def _pre_physics_step(self,actions):
   self._record_action(actions);self.targets.copy_(self.robot.data.default_joint_pos);lim=self.robot.data.joint_pos_limits[:,self.joint_ids];self.targets[:,self.joint_ids]=lim[:,:,0]+.5*(self.last_action+1)*(lim[:,:,1]-lim[:,:,0])
 env=ReachEnv(cfg);w=RslRlVecEnvWrapper(env,clip_actions=None);device=env.device;low=torch.tensor(LOW,device=device);high=torch.tensor(HIGH,device=device);mean=torch.tensor(INITIAL,device=device).clamp(low,high);sigma=(high-low)*.18;g=torch.Generator(device=device).manual_seed(a.seed)
 limits=env.robot.data.joint_pos_limits[0,env.joint_ids];default=env.robot.data.default_joint_pos[0,env.joint_ids];geometry=json.loads((ROOT/'reports/G07/feasibility_v3_20261023/geometry.json').read_text());arm=torch.tensor(geometry['poses']['effective_face_normal_x_ge_0.9']['arm_q_rad'],device=device)
 target=torch.tensor([1.4,0.,1.65],device=device);target_normal=torch.tensor([.96936,0.,.24565],device=device)
 def actions(obs,parameters):
  t=obs['policy'][:,775];ct,pt,tt=parameters[:,:3].unbind(1);crouch=(t>=.8)&(t<.8+ct);push=(t>=.8+ct)&(t<.8+ct+pt);tuck=(t>=.8+ct+pt)&(t<.8+ct+pt+tt);recover=t>=.8+ct+pt+tt
  q=default[None,:].repeat(a.num_envs,1)
  for front,sl in [(True,slice(4,6)),(False,slice(6,8))]:
   q[:,sl]=torch.where(crouch[:,None],default[sl]+parameters[:,3:4],torch.where(push[:,None],parameters[:,5 if front else 6,None]+parameters[:,8:9]*(1 if front else -1),torch.where(tuck[:,None],parameters[:,9:10],torch.where(recover[:,None],parameters[:,12 if front else 13,None],default[sl]))))
  q[:,8:12]=torch.where(crouch[:,None],default[8:12]+parameters[:,4:5],torch.where(push[:,None],parameters[:,7:8],torch.where(tuck[:,None],parameters[:,10:11],torch.where(recover[:,None],parameters[:,14:15],default[8:12]))))
  q[:,4:6]+=(recover*(parameters[:,15]*obs['policy'][:,6]+parameters[:,16]))[:,None];q[:,6:8]-=(recover*(parameters[:,15]*obs['policy'][:,6]+parameters[:,16]))[:,None]
  q[:,:12]-=(recover*parameters[:,11])[:,None]*obs['policy'][:,27:39]
  q[:,:4]+=parameters[:,17:21]*((crouch|push|tuck).float()[:,None])
  blend=((t-.25)/.45).clamp(0,1)*((2.05-t)/.35).clamp(0,1);q[:,12:]=torch.lerp(default[12:][None,:],arm[None,:]+parameters[:,21:27],blend[:,None])
  return (2*(q-limits[:,0])/(limits[:,1]-limits[:,0])-1).clamp(-1,1)
 history=[];best_score=-float('inf')
 try:
  for generation in range(a.generations):
   parameters=(mean[None,:]+sigma[None,:]*torch.randn((a.num_envs,len(low)),generator=g,device=device)).clamp(low,high);parameters[0]=mean
   env._episode_has_stepped.zero_();env._metrics_started=False;env.episode_records.clear();obs,_=w.reset();finished=torch.zeros(a.num_envs,dtype=torch.bool,device=device);best=torch.full((a.num_envs,),-100.,device=device);position=torch.zeros((a.num_envs,3),device=device);normal=position.clone();root=position.clone();time=torch.zeros(a.num_envs,device=device);apex=torch.zeros(a.num_envs,device=device);air=torch.zeros(a.num_envs,dtype=torch.bool,device=device)
   with torch.inference_mode():
    for _ in range(400):
     t=obs['policy'][:,775];d=env.robot.data;tool=d.body_pos_w[:,env.racket_body_id]-env.scene.env_origins;quat=d.body_quat_w[:,env.racket_body_id];n=quat_rotate(quat,torch.tensor([1.,0.,0.],device=device).expand(a.num_envs,-1));up_y=quat_rotate(quat,torch.tensor([0.,1.,0.],device=device).expand(a.num_envs,-1));up_z=quat_rotate(quat,torch.tensor([0.,0.,1.],device=device).expand(a.num_envs,-1));point=tool+.0325*n+.095*torch.sign(up_y[:,2:])*up_y+.095*torch.sign(up_z[:,2:])*up_z
     candidate=(~finished)&(t>=1.)&(t<=1.85);score=-5*(point-target).norm(dim=-1)-(n-target_normal).norm(dim=-1)+.5*env.observed_airborne.float()-.4*env.body_ground_seen.float();improved=candidate&(score>best);best[improved]=score[improved];position[improved]=point[improved];normal[improved]=n[improved];root[improved]=(d.root_pos_w-env.scene.env_origins)[improved];time[improved]=t[improved];air[improved]=env.observed_airborne[improved];apex=torch.where(~finished,torch.maximum(apex,d.root_pos_w[:,2]),apex)
     obs,_,done,_=w.step(actions(obs,parameters));finished|=done.bool()
   first={}
   for row in env.episode_records:first.setdefault(row['env_id'],row)
   recovery=torch.tensor([bool(first[i]['success']) for i in range(a.num_envs)],device=device);scores=best+.15*recovery.float();elite=scores.topk(max(8,a.num_envs//8)).indices;mean=.25*mean+.75*parameters[elite].mean(0);sigma=(.25*sigma+.75*parameters[elite].std(0)).clamp(min=(high-low)*.025);top=int(scores.argmax())
   result=dict(generation=generation,score=float(scores[top]),parameters=parameters[top].cpu().tolist(),virtual_ball_center_m=position[top].cpu().tolist(),face_normal_world=normal[top].cpu().tolist(),root_at_event_m=root[top].cpu().tolist(),event_time_s=float(time[top]),feet_airborne=bool(air[top]),recovery=bool(recovery[top]),root_apex_m=float(apex[top]),maximum_root_apex_m=float(apex.max()),root_start_x_m=a.root_x,kind='no-ball dynamic reach curriculum; not a smash demonstration or policy result')
   history.append(result);torch.save(dict(parameters=parameters.cpu(),scores=scores.cpu(),best_virtual_positions=position.cpu(),root_at_event=root.cpu(),root_apex=apex.cpu(),event_time=time.cpu(),feet_airborne=air.cpu(),recovery=recovery.cpu()),a.output/f'population_{generation:03d}.pt')
   if float(scores[top])>best_score:best_score=float(scores[top]);torch.save(dict(parameters=parameters[top].cpu(),arm_pose=arm.cpu(),result=result),a.output/'best_candidate.pt')
   (a.output/'metrics.json').write_text(json.dumps(dict(history=history,best=max(history,key=lambda r:r['score']),env_steps=(generation+1)*a.num_envs*400),indent=2)+'\n');print(json.dumps(result),flush=True)
   if stopping:break
  if len(history)==a.generations:(a.output/'completed.json').write_text(json.dumps(dict(completed_generations=len(history),requested_generations=a.generations))+'\n')
 finally:env.close()

try:main()
except BaseException:
 a.output.mkdir(parents=True,exist_ok=True);error=traceback.format_exc();(a.output/'error.txt').write_text(error);print(error,file=sys.stderr,flush=True);raise
finally:app.close(skip_cleanup=True)
