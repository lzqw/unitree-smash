#!/usr/bin/env python3
"""Measure the G04 actor's actual racket pose during one ground rollout."""
import argparse, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from isaaclab.app import AppLauncher
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--checkpoint',type=Path,default=ROOT/'artifacts/G04/policy.pt');AppLauncher.add_app_launcher_args(p);a=p.parse_args();app=AppLauncher(a).app
import torch
from isaaclab_rl.rsl_rl import RslRlVecEnvWrapper
from quadsmash.tasks.stand.virtual_env import VirtualHitEnv,VirtualHitEnvCfg
from quadsmash.rl.native_ppo import NativeRunner
env=None
try:
 cfg=VirtualHitEnvCfg();cfg.scene.num_envs=64;cfg.sim.device='cuda:0';cfg.seed=200200
 env=VirtualHitEnv(cfg);w=RslRlVecEnvWrapper(env,clip_actions=None)
 config=json.loads((ROOT/'configs/g04_imitation.json').read_text());runner=NativeRunner(w,config['runner'],log_dir=str(a.output/'ppo'),device=env.device);runner.load(str(a.checkpoint),load_optimizer=False);policy=runner.get_inference_policy(device=env.device)
 obs,_=w.reset();records=[]
 with torch.inference_mode():
  for tick in range(400):
   t=tick*.01
   if .8<=t<=1.5:
    pos=env.robot.data.body_pos_w[:,env.racket_body_id]-env.scene.env_origins
    quat=env.robot.data.body_quat_w[:,env.racket_body_id]
    from isaaclab.utils import math as m
    n=m.quat_apply(quat,torch.tensor([1.,0.,0.],device=env.device).expand(env.num_envs,-1))
    records.append(dict(time_s=t,position_mean=pos.mean(0).cpu().tolist(),position_min=pos.min(0).values.cpu().tolist(),position_max=pos.max(0).values.cpu().tolist(),normal_mean=n.mean(0).cpu().tolist(),normal_x_min=float(n[:,0].min()),normal_x_max=float(n[:,0].max())))
   obs,_,_,_=w.step(policy(obs))
 a.output.mkdir(parents=True,exist_ok=True);(a.output/'trajectory.json').write_text(json.dumps(records,indent=2));print(json.dumps(records[::10]),flush=True)
finally:
 if env is not None:env.close()
 app.close(skip_cleanup=True)
