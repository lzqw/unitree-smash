#!/usr/bin/env python3
"""Record the bounded G06 teacher's real-ball and racket trajectory."""
import argparse, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from isaaclab.app import AppLauncher
p = argparse.ArgumentParser(); p.add_argument('--output', type=Path, required=True); p.add_argument('--physics-dt', type=float, default=.00025)
AppLauncher.add_app_launcher_args(p); a = p.parse_args(); app = AppLauncher(a).app
import torch
from isaaclab_rl.rsl_rl import RslRlVecEnvWrapper
from quadsmash.tasks.stand.ball_env import BallEnv, BallEnvCfg
from quadsmash.control.jump_teacher import teacher_action

P = [0.2620947659,0.1344715506,0.9543790817,0.8255642056,0.4831368923,1.0,
     -0.3079007566,0.3499999940,-0.1971214861,-0.9468204977,0.1242316961,
     0.1379330605,0.0928989127,-0.2010091096]
env = None
try:
    cfg = BallEnvCfg(); cfg.scene.num_envs = 1; cfg.seed = 611022; cfg.sim.device = 'cuda:0'; cfg.sim.dt = a.physics_dt; cfg.decimation = round(.01/a.physics_dt); cfg.sim.render_interval = cfg.decimation
    env = BallEnv(cfg); wrapped = RslRlVecEnvWrapper(env, clip_actions=None); obs, _ = wrapped.reset()
    params = torch.tensor(P, device=env.device).repeat(1,1); rows=[]
    with torch.inference_mode():
        for tick in range(400):
            if tick % 5 == 0:
                r = env.robot.data.body_pos_w[0, env.racket_body_id] - env.scene.env_origins[0]
                b = env.shuttle.data.root_pos_w[0] - env.scene.env_origins[0]
                force = env.shuttle_contact.data.force_matrix_w[0, 0].norm(dim=-1).cpu().tolist()
                rows.append({'time_s': tick*.01, 'racket_xyz': r.cpu().tolist(), 'ball_xyz': b.cpu().tolist(), 'distance_m': float((r-b).norm()), 'contact_force_channels_n': force, 'airborne': bool(env.observed_airborne[0]), 'feet': int(env.observed_foot_contact[0].sum())})
            obs, _, _, _ = wrapped.step(teacher_action(obs['policy'], params))
    a.output.mkdir(parents=True, exist_ok=True); (a.output/'trajectory.json').write_text(json.dumps(rows, indent=2)); print(json.dumps(rows, indent=2), flush=True)
finally:
    if env is not None: env.close()
    app.close(skip_cleanup=True)
