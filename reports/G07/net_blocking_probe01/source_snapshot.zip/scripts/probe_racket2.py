#!/usr/bin/env python3
"""Print the native racket pose and joint mapping for teacher design."""
import argparse, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from isaaclab.app import AppLauncher
p=argparse.ArgumentParser();AppLauncher.add_app_launcher_args(p);a=p.parse_args();app=AppLauncher(a).app
import torch
from isaaclab_rl.rsl_rl import RslRlVecEnvWrapper
from quadsmash.tasks.stand.virtual_env import VirtualHitEnv, VirtualHitEnvCfg
env=None
try:
 cfg=VirtualHitEnvCfg();cfg.scene.num_envs=4;cfg.sim.device='cuda:0';cfg.seed=1907
 env=VirtualHitEnv(cfg);w=RslRlVecEnvWrapper(env,clip_actions=None);obs,_=w.reset()
 for _ in range(3):
  print(json.dumps({
   'goal_position':env.goal_position_w[:4].detach().cpu().tolist(),
   'goal_normal':env.goal_normal_w[:4].detach().cpu().tolist(),
   'goal_time':env.goal_time_s[:4].detach().cpu().tolist(),
   'racket_position':env.robot.data.body_pos_w[:4,env.racket_body_id].detach().cpu().tolist(),
   'racket_quaternion':env.robot.data.body_quat_w[:4,env.racket_body_id].detach().cpu().tolist(),
   'joint_names':env.robot.joint_names,'joint_ids':env.joint_ids,
   'body_names':env.robot.body_names,
  }),flush=True)
  obs,_,_,_=w.step(torch.zeros((env.num_envs,18),device=env.device))
finally:
 if env is not None:env.close()
 app.close(skip_cleanup=True)
