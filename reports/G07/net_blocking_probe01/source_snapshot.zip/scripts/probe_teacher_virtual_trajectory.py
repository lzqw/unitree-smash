#!/usr/bin/env python3
"""Measure a bounded jump teacher trajectory on the native VirtualHitEnv."""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from isaaclab.app import AppLauncher
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);AppLauncher.add_app_launcher_args(p);a=p.parse_args();app=AppLauncher(a).app
import torch
from isaaclab_rl.rsl_rl import RslRlVecEnvWrapper
from quadsmash.tasks.stand.virtual_env import VirtualHitEnv,VirtualHitEnvCfg
from quadsmash.control.jump_teacher import teacher_action
P=[0.2620947659,0.1344715506,0.9543790817,0.8255642056,0.4831368923,1.0,-0.3079007566,0.3499999940,-0.1971214861,-0.9468204977,0.1242316961,0.1379330605,0.0928989127,-0.2010091096]
env=None
try:
 cfg=VirtualHitEnvCfg();cfg.scene.num_envs=64;cfg.sim.device='cuda:0';cfg.seed=200200
 env=VirtualHitEnv(cfg);w=RslRlVecEnvWrapper(env,clip_actions=None);obs,_=w.reset();params=torch.tensor(P,device=env.device).repeat(env.num_envs,1);rows=[]
 with torch.inference_mode():
  for tick in range(400):
   t=tick*.01
   if .8<=t<=1.8:
    pos=env.robot.data.body_pos_w[:,env.racket_body_id]-env.scene.env_origins;quat=env.robot.data.body_quat_w[:,env.racket_body_id]
    from isaaclab.utils import math as m
    n=m.quat_apply(quat,torch.tensor([1.,0.,0.],device=env.device).expand(env.num_envs,-1))
    rows.append(dict(time_s=t,airborne=bool(env.observed_airborne[0]),feet=int(env.observed_foot_contact[0].sum()),position_mean=pos.mean(0).cpu().tolist(),normal_mean=n.mean(0).cpu().tolist(),velocity_mean=env.robot.data.body_vel_w[:,env.racket_body_id,:3].mean(0).cpu().tolist()))
   obs,_,_,_=w.step(teacher_action(obs['policy'],params))
 a.output.mkdir(parents=True,exist_ok=True);(a.output/'trajectory.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows[::10]),flush=True)
finally:
 if env is not None:env.close()
 app.close(skip_cleanup=True)
