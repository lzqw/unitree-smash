#!/usr/bin/env python3
"""Probe G06 leg actor plus an observation-time high-arm action head."""
import argparse,csv,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from isaaclab.app import AppLauncher
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--num-envs',type=int,default=64);p.add_argument('--physics-dt',type=float,default=.00025);p.add_argument('--checkpoint',type=Path,default=ROOT/'artifacts/G06/policy.pt');p.add_argument('--switch',type=float,default=1.16);AppLauncher.add_app_launcher_args(p);a=p.parse_args();app=AppLauncher(a).app
import torch
from isaaclab_rl.rsl_rl import RslRlVecEnvWrapper
from rsl_rl.runners import OnPolicyRunner
from quadsmash.tasks.stand.ball_env import BallEnv,BallEnvCfg

QPRE=torch.tensor([.13985,1.47213,-2.90887,1.29097,-1.17635,-.01722]);QLATE=torch.tensor([-.675925,1.060654,-1.455027,.369168,-.298615,-.248977])
try:
 a.output.mkdir(parents=True,exist_ok=True);cfg=BallEnvCfg();cfg.scene.num_envs=a.num_envs;cfg.seed=613070;cfg.sim.device='cuda:0';cfg.sim.dt=a.physics_dt;cfg.decimation=round(.01/a.physics_dt);cfg.sim.render_interval=cfg.decimation;cfg.episode_length_s=4.;cfg.include_net=True;cfg.arm_action_scale=2.;cfg.shuttle_start=(8.18,0.,1.15);cfg.shuttle_velocity=(-6.6,0.,6.82);cfg.event_goal_position=(.3,0.,1.25);cfg.event_goal_normal=(0.,0.,1.);cfg.event_goal_velocity=(0.,0.,0.)
 env=BallEnv(cfg);w=RslRlVecEnvWrapper(env,clip_actions=1.0);config=json.loads((ROOT/'configs/g05_imitation.json').read_text());runner=OnPolicyRunner(w,config['runner'],log_dir=str(a.output/'ppo'),device=env.device);runner.load(str(a.checkpoint.resolve()),load_optimizer=False);policy=runner.get_inference_policy(device=env.device);default=env.robot.data.default_joint_pos[0,env.joint_ids[12:]].clone();pre=((QPRE.to(env.device)-default)/2.).view(1,6);late=((QLATE.to(env.device)-default)/2.).view(1,6);obs,_=w.reset()
 with torch.inference_mode():
  for _ in range(400):
   action=policy(obs);t=obs['policy'][:,775];arm=torch.zeros((a.num_envs,6),device=env.device);active=(t>=.70)&(t<1.42);arm[active]=torch.where((t[active]<a.switch)[:,None],pre,late);action[:,12:]=arm;obs,_,_,_=w.step(action)
 rows=[]
 for i,r in enumerate(env.ball_episode_records): rows.append({'env_id':i,'contact':bool(r['contact']),'airborne_contact':bool(r['airborne_contact']),'body_contact':bool(r['body_contact']),'outgoing_speed_mps':float(r['outgoing_speed_mps']),'outgoing_vz_mps':float(r['outgoing_vz_mps']),'crossed_net':bool(r['crossed_net']),'landed_target':bool(r['landed_target']),'recovery_success':bool(r['recovery_success']),'contact_time_s':float(r['contact_time_s']),'ball_xyz':r['ball_min_distance_ball_xyz'],'tool_xyz':r['ball_min_distance_tool_xyz']})
 m={'physics_dt_s':a.physics_dt,'switch_s':a.switch,'episodes':len(rows),'contact':sum(v['contact'] for v in rows),'airborne_contact':sum(v['airborne_contact'] for v in rows),'attack':sum(v['contact'] and v['outgoing_speed_mps']>=8 and v['outgoing_vz_mps']<=-1 for v in rows),'recovery':sum(v['recovery_success'] for v in rows),'crossed_net':sum(v['crossed_net'] for v in rows),'max_speed':max(v['outgoing_speed_mps'] for v in rows),'min_vz':min(v['outgoing_vz_mps'] for v in rows),'variants':rows};(a.output/'metrics.json').write_text(json.dumps(m,indent=2)+'\n');
 with (a.output/'episodes.csv').open('w',newline='') as f: wr=csv.DictWriter(f,fieldnames=sorted(rows[0]));wr.writeheader();wr.writerows(rows)
 print(json.dumps({k:m[k] for k in ('episodes','contact','airborne_contact','attack','recovery','crossed_net','max_speed','min_vz')},sort_keys=True),flush=True)
finally:
 try:env.close()
 except:pass
 app.close(skip_cleanup=True)
