#!/usr/bin/env python3
"""Probe kinematic racket reach over the current arm action band."""
import argparse, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from isaaclab.app import AppLauncher
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=ROOT/'reports/G05/probe_arm_workspace');AppLauncher.add_app_launcher_args(p);a=p.parse_args();app=AppLauncher(a).app
import torch
from quadsmash.tasks.stand.virtual_env import VirtualHitEnv,VirtualHitEnvCfg
env=None
try:
 cfg=VirtualHitEnvCfg();cfg.scene.num_envs=4096;cfg.sim.device='cuda:0';cfg.seed=1907
 env=VirtualHitEnv(cfg)
 g=torch.Generator(device=env.device).manual_seed(7788)
 q=env.robot.data.default_joint_pos.clone();q[:,env.joint_ids[12:]] += .12*(2*torch.rand((env.num_envs,6),generator=g,device=env.device)-1)
 env.robot.write_joint_state_to_sim(q,torch.zeros_like(q));env.sim.forward()
 pos=env.robot.data.body_pos_w[:,env.racket_body_id];quat=env.robot.data.body_quat_w[:,env.racket_body_id]
 from isaaclab.utils import math as m
 n=m.quat_apply(quat,torch.tensor([1.,0.,0.],device=env.device).expand(env.num_envs,-1))
 out=dict(position_min=pos.min(0).values.cpu().tolist(),position_max=pos.max(0).values.cpu().tolist(),normal_x_min=float(n[:,0].min()),normal_x_max=float(n[:,0].max()),normal_mean=n.mean(0).cpu().tolist(),samples=env.num_envs)
 a.output.mkdir(parents=True,exist_ok=True);(a.output/'metrics.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True)
finally:
 if env is not None:env.close()
 app.close(skip_cleanup=True)
