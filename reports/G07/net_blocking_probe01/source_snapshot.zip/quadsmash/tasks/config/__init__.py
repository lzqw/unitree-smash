"""Task configuration package."""

